/*
 * CodePress regular expressions for Text syntax highlighting
 */

// do nothing, as expected 
Language.syntax = []
Language.snippets = []
Language.complete = []
Language.shortcuts = []